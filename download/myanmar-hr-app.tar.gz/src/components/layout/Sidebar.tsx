'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Kanban,
  UserCircle,
  Mail,
  Settings,
  LogOut,
  Building2
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Clients', href: '/clients', icon: Users },
  { name: 'Job Orders', href: '/jobs', icon: Briefcase },
  { name: 'Pipeline', href: '/pipeline', icon: Kanban },
  { name: 'Candidates', href: '/candidates', icon: UserCircle },
  { name: 'Outreach', href: '/outreach', icon: Mail },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <div className="flex h-full w-64 flex-col bg-slate-900 text-white">
      <div className="flex h-16 items-center gap-2 px-6 border-b border-slate-700">
        <Building2 className="h-8 w-8 text-blue-400" />
        <div>
          <h1 className="text-lg font-bold">MyanmarHR</h1>
          <p className="text-xs text-slate-400">Recruitment Agency</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-4">
        {navigation.map((item) => {
          const isActive = pathname === item.href || 
            (item.href !== '/' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-slate-700 p-3 space-y-1">
        <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors">
          <Settings className="h-5 w-5" />
          Settings
        </button>
      </div>

      <div className="border-t border-slate-700 p-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center font-medium">
            DM
          </div>
          <div>
            <p className="text-sm font-medium">Daw Mya</p>
            <p className="text-xs text-slate-400">Senior Recruiter</p>
          </div>
        </div>
      </div>
    </div>
  );
}
