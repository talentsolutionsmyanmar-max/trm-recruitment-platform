'use client';

import { useMemo } from 'react';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { mockJobs, mockDeals, mockActivities, getDashboardMetrics, formatMMK } from '@/lib/data';
import { Users, Briefcase, TrendingUp, UserCheck, Plus, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const metrics = useMemo(() => getDashboardMetrics(), []);
  const activeJobs = mockJobs.filter(j => j.status === 'open' || j.status === 'in-progress').slice(0, 5);
  const activeDeals = mockDeals.filter(d => d.stage !== 'won' && d.stage !== 'lost').slice(0, 5);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Dashboard" subtitle="Welcome back, Daw Mya" />
        
        <main className="flex-1 overflow-auto p-6 bg-slate-50">
          {/* Quick Actions */}
          <div className="flex gap-3 mb-6">
            <Link href="/clients">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Client
              </Button>
            </Link>
            <Link href="/jobs">
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Create Job Order
              </Button>
            </Link>
            <Link href="/candidates">
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Candidate
              </Button>
            </Link>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MetricCard
              title="Active Clients"
              value={metrics.totalClients}
              change={metrics.clientsChange}
              icon={Users}
              iconColor="text-blue-600"
            />
            <MetricCard
              title="Active Jobs"
              value={metrics.activeJobs}
              change={metrics.jobsChange}
              icon={Briefcase}
              iconColor="text-purple-600"
            />
            <MetricCard
              title="Pipeline Value"
              value={formatMMK(metrics.pipelineValue)}
              change={metrics.pipelineChange}
              icon={TrendingUp}
              iconColor="text-green-600"
            />
            <MetricCard
              title="Placements This Month"
              value={metrics.placementsThisMonth}
              change={metrics.placementsChange}
              icon={UserCheck}
              iconColor="text-orange-600"
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Active Jobs */}
            <Card className="lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-semibold">Active Job Orders</CardTitle>
                <Link href="/jobs">
                  <Button variant="ghost" size="sm">
                    View All <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activeJobs.map((job) => (
                    <div key={job.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div>
                        <p className="font-medium text-slate-900">{job.title}</p>
                        <p className="text-sm text-slate-500">{job.clientName}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-slate-700">
                          {job.filled}/{job.quantity} filled
                        </p>
                        <p className="text-xs text-slate-400">{job.location}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Activity Feed */}
            <ActivityFeed activities={mockActivities.slice(0, 5)} />
          </div>

          {/* Pipeline Summary */}
          <div className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-semibold">Pipeline Overview</CardTitle>
                <Link href="/pipeline">
                  <Button variant="ghost" size="sm">
                    Open Pipeline <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-5 gap-4">
                  {['lead', 'qualified', 'proposal', 'negotiation', 'won'].map((stage) => {
                    const stageDeals = mockDeals.filter(d => d.stage === stage);
                    const totalValue = stageDeals.reduce((sum, d) => sum + d.value, 0);
                    return (
                      <div key={stage} className="text-center p-4 bg-slate-50 rounded-lg">
                        <p className="text-2xl font-bold text-slate-700">{stageDeals.length}</p>
                        <p className="text-sm text-slate-500 capitalize">{stage}</p>
                        <p className="text-xs text-slate-400 mt-1">{formatMMK(totalValue)}</p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
