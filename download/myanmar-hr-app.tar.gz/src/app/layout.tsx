import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MyanmarHR - Recruitment Agency Platform",
  description: "Modern recruitment agency management platform for Myanmar. CRM, ATS, and AI-powered candidate matching.",
  keywords: ["Myanmar", "Recruitment", "HR", "CRM", "ATS", "Staffing"],
  authors: [{ name: "MyanmarHR Team" }],
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} antialiased bg-slate-50 text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
